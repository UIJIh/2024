import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
from torch.nn import functional as F
from torch.utils.tensorboard import SummaryWriter
import random
import argparse
random.seed(0)

import dataset
import model
import trainer
import utils


argp = argparse.ArgumentParser()
argp.add_argument('function', help="Choose pretrain, finetune, or evaluate")
argp.add_argument('variant', help="Choose vanilla or perceiver") 
argp.add_argument('--bottleneck_dim', type=int, default=32)
argp.add_argument('pretrain_corpus_path', default=None)
argp.add_argument('--reading_params_path',default=None)
argp.add_argument('--writing_params_path',default=None)
argp.add_argument('--finetune_corpus_path', default=None)
argp.add_argument('--eval_corpus_path', default=None)
argp.add_argument('--outputs_path', default=None)
argp.add_argument('--pretrain_lr', default=6e-3, type=float)
argp.add_argument('--finetune_lr', default=6e-4, type=float)
argp.add_argument('--tb_expt_name', help='debug string for tb log.',
                  default='run')
args = argp.parse_args()

# Save the device
device = torch.cuda.current_device() if torch.cuda.is_available() else 'cpu'

# TensorBoard training log
writer = SummaryWriter(log_dir='expt/%s/%s_%s_%d_pt_lr_%f_ft_lr_%f' % (
    args.function,
    args.tb_expt_name,
    args.variant,
    args.bottleneck_dim,
    args.pretrain_lr,
    args.finetune_lr))

# Keep the block size 128
# Why is the pretraining corpus always required (even if we're not pretraining?)
# It's because we're using it as a hack to always have the same vocabulary
# (that is, the same mapping from character to integer, and we build the
# vocab from the pretraining corpus.)
block_size = 128
text = open(args.pretrain_corpus_path, encoding='utf-8').read()
pretrain_dataset = dataset.CharCorruptionDataset(text, block_size)

# We don't suggest you change these hyperparameters, as they're known to work.
# use them for both the vanilla and the perceiver models
mconf = model.GPTConfig(pretrain_dataset.vocab_size, pretrain_dataset.block_size,
    n_layer=4, n_head=8, n_embd=256)

"""
Don't change above here; write your code below
"""

# define models.
# note: models should moved to device defined on line 34.

if args.variant == 'vanilla':
    # [part c] Make some model here (one to initailize the model / one to finetune it -> 뒤에 있음)
    model = model.GPT(mconf).to(device)
elif args.variant == 'perceiver':
    # set mconf.perceiver, and mconf.bottleneck_dim parameters appropriately.
    # [part g] Make some other model here
    mconf.perceiver = True
    mconf.bottleneck_dim = args.bottleneck_dim # 고차원 입력을 latent bottleneck이라는 저차원 공간으로 매핑...
    model = model.GPT(mconf).to(device)
    '''
    Perceiver는 2021년에 제안된 신경망 구조로, 다양한 형태의 고차원 데이터를 효율적으로 처리하기 위해 설계되었습니다. 특히, 이미지, 텍스트, 오디오와 같은 서로 다른 유형의 데이터를 하나의 모델로 처리할 수 있는 유연성을 가지고 있습니다. Perceiver 구조는 Transformers에서 영감을 받았지만, 높은 차원의 데이터를 효과적으로 처리할 수 있도록 몇 가지 독특한 특징을 가지고 있습니다.

### Perceiver 구조의 주요 특징

1. **입력 처리 방식:**
   - Perceiver는 대규모 입력 데이터를 효과적으로 처리하기 위해 **입력 압축**(Input Compression)을 사용합니다. 일반적인 Transformer는 모든 입력 토큰에 대해 self-attention을 계산하지만, Perceiver는 입력 데이터를 저차원 표현으로 압축하는 단계가 있습니다.
   - 이 과정에서 Perceiver는 고차원 입력을 **latent bottleneck**(잠재 병목)이라는 저차원 공간으로 매핑합니다. 이로 인해, 직접적으로 모든 입력 데이터를 처리하는 대신, 이 저차원 표현에 집중할 수 있습니다.

2. **Latent Bottleneck:**
   - 이 구조는 입력 데이터를 병목지점(bottleneck)에 압축한 후, 이 압축된 표현을 이용해 연산을 수행합니다. 따라서 모델이 처리해야 할 데이터의 차원이 크게 줄어들고, 이는 메모리와 연산 효율성을 높이는 데 도움이 됩니다.
   - 이 과정에서 잠재 벡터(latent vectors)는 입력 데이터를 요약하는 역할을 합니다.

3. **Cross-attention:**
   - Perceiver는 입력과 잠재 벡터 간의 상호작용을 위해 **cross-attention** 메커니즘을 사용합니다. 이 메커니즘은 입력 데이터를 잠재 벡터로 변환하는 데 사용되며, 이 과정에서 잠재 벡터가 입력 데이터의 중요한 정보를 요약할 수 있게 합니다.

4. **Self-attention on Latent Space:**
   - 잠재 벡터들 간에는 일반적인 self-attention을 사용하여 정보를 통합하고, 이를 바탕으로 최종 출력을 생성합니다.
   - 이 방식은 높은 차원의 데이터를 직접 다루는 Transformer와 달리, 저차원 공간에서 연산이 이루어지므로 계산 비용이 줄어듭니다.

5. **다양한 입력 데이터 처리:**
   - Perceiver는 구조적으로 매우 유연해서 이미지, 텍스트, 오디오, 비디오 등 여러 형태의 데이터를 처리할 수 있습니다. 입력 데이터의 유형에 관계없이 동일한 모델 아키텍처를 사용할 수 있다는 점에서 매우 강력합니다.

### Perceiver의 장점

- **확장성:** Perceiver는 고차원 입력 데이터를 효율적으로 처리하기 때문에, 매우 큰 입력 데이터를 다룰 때도 성능이 잘 유지됩니다.
- **유연성:** 다양한 입력 형식(이미지, 텍스트 등)을 하나의 모델로 처리할 수 있다는 점에서 매우 유연합니다.
- **효율성:** 데이터의 차원을 줄여서 처리하기 때문에 메모리 사용량과 연산 비용이 감소합니다.

### Perceiver 구조의 실제 적용 예시

이 모델은 이미지 분류, 자연어 처리, 오디오 신호 처리 등 다양한 작업에 적용될 수 있습니다. 예를 들어, 이미지 데이터가 입력으로 주어졌을 때, Perceiver는 이미지를 작은 패치로 나눈 후, 이 패치들을 latent bottleneck에 매핑하여 정보를 요약하고, 이를 바탕으로 최종 이미지를 분류할 수 있습니다.

### 결론

Perceiver는 대규모의 복잡한 데이터를 효율적으로 처리하기 위해 고안된 구조로, 특히 다양한 데이터 유형을 처리할 수 있는 유연성과 효율성에서 큰 장점을 가지고 있습니다. 일반적인 Transformer와 달리, 입력 데이터를 저차원으로 압축하여 연산 효율을 높이는 것이 핵심 아이디어입니다.
    '''
else:
    raise ValueError("Unknown model variant")

# Perform pretraining, finetuning, or evaluation
if args.function == 'pretrain':
    assert args.writing_params_path is not None # 주어질거라고 했음 or AssertionError
    # TODO [part f]:
    # - Given:
    #     1. A corpus specified in args.pretrain_corpus_path
    #     2. An output path args.writing_params_path for the model parameters
    # - Goals:
    #     1. Pretrain the model on this corpus
    #     2. Save the resulting model in args.writing_params_path
    
    # - Make sure to use the following hyperparameters for pretraining:
    # Hyperparameters for pretraining:
    # max_epochs=650
    # batch_size=128
    # learning_rate=args.pretrain_lr
    # lr_decay=True
    # warmup_tokens=512*20
    # final_tokens=200*len(pretrain_dataset)*block_size
    # num_workers=4
    # writer=writer 
    assert args.pretrain_corpus_path is not None

    tconf = trainer.TrainerConfig(
        max_epochs=650,
        batch_size=128,
        learning_rate=args.pretrain_lr,
        lr_decay=True,
        warmup_tokens=512*20,
        final_tokens=200*len(pretrain_dataset)*block_size,
        num_workers=4,
        writer=writer
    )

    trainer = trainer.Trainer(model, pretrain_dataset, None, tconf) # None; val_dataset
    trainer.train()
    torch.save(model.state_dict(), args.writing_params_path) # dict; dictionary
    raise NotImplementedError

elif args.function == 'finetune':
    assert args.writing_params_path is not None
    # TODO [part c] [part f]:
    # - Given:
    #     1. A finetuning corpus specified in args.finetune_corpus_path
    #     2. A path args.reading_params_path containing pretrained model
    #         parameters, or None if finetuning without a pretrained model
    #     3. An output path args.writing_params_path for the model parameters
    # - Goals:
    #     1. If args.reading_params_path is specified, load these parameters
    #         into the model
    #     2. Finetune the model on this corpus
    #     3. Save the resulting model in args.writing_params_path
    # - Make sure to use the following hyperparameters:
    #     [part d] Hyperparameters for finetuning WITHOUT a pretrained model:
    #         max_epochs=75
    #         batch_size=256
    #         learning_rate=args.finetune_lr
    #         lr_decay=True
    #         warmup_tokens=512*20
    #         final_tokens=200*len(pretrain_dataset)*block_size
    #         num_workers=4
    #         writer=writer

    #     [part f] Hyperparameters for finetuning WITH a pretrained model:
    #         max_epochs=10
    #         batch_size=256
    #         learning_rate=args.finetune_lr
    #         lr_decay=True
    #         warmup_tokens=512*20
    #         final_tokens=200*len(pretrain_dataset)*block_size
    #         num_workers=4
    #         writer=writer
    #     You can use the args.reading_params_path flag to switch between the
    #     number of epochs for each case.
    
    if args.reading_params_path is None: # w/o pretraining
        tconf = trainer.TrainerConfig(
            max_epochs=75,
            batch_size=256,
            learning_rate=args.finetune_lr,
            lr_decay=True,
            warmup_tokens=512*20,
            final_tokens=200*len(pretrain_dataset)*block_size,
            num_workers=4,
            writer=writer
        )
    else: # args.reading_params_path is not None == w/ pretrainng
        model.load_state_dict(torch.load(args.reading_params_path))
        tconf = trainer.TrainerConfig(
            max_epochs=10,
            batch_size=256,
            learning_rate=args.finetune_lr,
            lr_decay=True,
            warmup_tokens=512*20,
            final_tokens=200*len(pretrain_dataset)*block_size,
            num_workers=2,
            writer=writer
        )

    # 이제 finetuning!
    ## 1) dataset 불러오기
    finetune_corpus = open(args.finetune_corpus_path).read()
    finetune_dataset = dataset.NameDataset(pretrain_dataset, finetune_corpus)
    ## 2) trainer 모듈
    trainer = trainer.Trainer(model, finetune_dataset, None, tconf)
    trainer.train()
    ## 3) save
    torch.save(model.state_dict(), args.writing_params_path)

    raise NotImplementedError
elif args.function == 'evaluate':
    assert args.outputs_path is not None
    assert args.reading_params_path is not None
    assert args.eval_corpus_path is not None
    model.load_state_dict(torch.load(args.reading_params_path))
    correct = 0
    total = 0
    with open(args.outputs_path, 'w', encoding='utf-8') as fout:
        predictions = []
        for line in tqdm(open(args.eval_corpus_path, encoding='utf-8')):
            x = line.split('\t')[0]
            x = x + '⁇'
            x = torch.tensor([pretrain_dataset.stoi[s] for s in x], dtype=torch.long)[None,...].to(device)
            pred = utils.sample(model, x, 32, sample=False)[0]
            completion = ''.join([pretrain_dataset.itos[int(i)] for i in pred])
            pred = completion.split('⁇')[1]
            predictions.append(pred)
            fout.write(pred + '\n')
        total, correct = utils.evaluate_places(args.eval_corpus_path, predictions)
    if total > 0:
      print('Correct: {} out of {}: {}%'.format(correct, total, correct/total*100))
    else:
        print('Predictions written to {}; no targets provided'
                .format(args.outputs_path))

